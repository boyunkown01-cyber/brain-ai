package com.example.data.repository

import com.example.data.api.GeminiAiService
import com.example.data.local.dao.BrainDao
import com.example.data.local.entities.CommandLogEntity
import com.example.data.local.entities.PluginEntity
import com.example.data.local.entities.TaskEntity
import com.example.data.local.entities.VaultSecretEntity
import kotlinx.coroutines.flow.Flow

class BrainRepository(private val dao: BrainDao) {

    // Tasks
    val allTasks: Flow<List<TaskEntity>> = dao.getAllTasks()
    suspend fun insertTask(task: TaskEntity): Long = dao.insertTask(task)
    suspend fun updateTask(task: TaskEntity) = dao.updateTask(task)
    suspend fun deleteTask(task: TaskEntity) = dao.deleteTask(task)
    suspend fun deleteTaskById(id: Long) = dao.deleteTaskById(id)

    // Logs
    val recentLogs: Flow<List<CommandLogEntity>> = dao.getRecentLogs()
    suspend fun logCommand(
        rawCommand: String,
        actionType: String,
        responseSummary: String,
        isSuccess: Boolean = true,
        isVoice: Boolean = false
    ): Long {
        val entity = CommandLogEntity(
            rawCommand = rawCommand,
            actionType = actionType,
            responseSummary = responseSummary,
            isSuccess = isSuccess,
            isVoice = isVoice
        )
        return dao.insertCommandLog(entity)
    }
    suspend fun clearLogs() = dao.clearAllLogs()

    // Vault
    val allVaultSecrets: Flow<List<VaultSecretEntity>> = dao.getAllVaultSecrets()
    suspend fun insertSecret(secret: VaultSecretEntity): Long = dao.insertVaultSecret(secret)
    suspend fun deleteSecret(secret: VaultSecretEntity) = dao.deleteVaultSecret(secret)

    // Plugins
    val allPlugins: Flow<List<PluginEntity>> = dao.getAllPlugins()
    suspend fun insertPlugin(plugin: PluginEntity) = dao.insertPlugin(plugin)
    suspend fun updatePlugin(plugin: PluginEntity) = dao.updatePlugin(plugin)
    suspend fun deletePlugin(plugin: PluginEntity) = dao.deletePlugin(plugin)

    // AI
    suspend fun queryGemini(prompt: String, context: String = ""): String {
        return GeminiAiService.askJarvis(prompt, context)
    }
}
