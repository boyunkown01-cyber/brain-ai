package com.example.engine

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import com.example.service.BrainAccessibilityService
import java.net.URLEncoder

sealed class ActionResult {
    data class Success(val message: String, val speechResponse: String? = null) : ActionResult()
    data class Failure(val message: String) : ActionResult()
    data class ScreenAnalysis(val content: String) : ActionResult()
}

class DeviceActionExecutor(private val context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager

    // --- Flashlight ---
    fun setFlashlight(enabled: Boolean): ActionResult {
        return try {
            val cameraId = cameraManager?.cameraIdList?.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (cameraId != null) {
                cameraManager?.setTorchMode(cameraId, enabled)
                val status = if (enabled) "Flashlight activated" else "Flashlight deactivated"
                ActionResult.Success(status, status)
            } else {
                ActionResult.Failure("Flashlight hardware unavailable")
            }
        } catch (e: Exception) {
            ActionResult.Failure("Flashlight error: ${e.localizedMessage}")
        }
    }

    // --- Audio & Volume ---
    fun changeVolume(delta: Int): ActionResult {
        return try {
            val stream = AudioManager.STREAM_MUSIC
            if (delta > 0) {
                audioManager?.adjustStreamVolume(stream, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                ActionResult.Success("Volume increased", "Volume increased")
            } else if (delta < 0) {
                audioManager?.adjustStreamVolume(stream, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                ActionResult.Success("Volume lowered", "Volume lowered")
            } else {
                ActionResult.Success("Volume unchanged")
            }
        } catch (e: Exception) {
            ActionResult.Failure("Volume error: ${e.localizedMessage}")
        }
    }

    fun setVolumeMax(): ActionResult {
        return try {
            val stream = AudioManager.STREAM_MUSIC
            val max = audioManager?.getStreamMaxVolume(stream) ?: 15
            audioManager?.setStreamVolume(stream, max, AudioManager.FLAG_SHOW_UI)
            ActionResult.Success("Volume set to maximum", "Volume set to maximum")
        } catch (e: Exception) {
            ActionResult.Failure("Volume error: ${e.localizedMessage}")
        }
    }

    fun setVolumeMute(): ActionResult {
        return try {
            val stream = AudioManager.STREAM_MUSIC
            audioManager?.setStreamVolume(stream, 0, AudioManager.FLAG_SHOW_UI)
            ActionResult.Success("Audio muted", "Audio muted")
        } catch (e: Exception) {
            ActionResult.Failure("Mute error: ${e.localizedMessage}")
        }
    }

    // --- App Launching ---
    fun launchAppByName(appName: String): ActionResult {
        val pm = context.packageManager
        val cleanName = appName.trim().lowercase()

        // Known quick mappings
        val knownPackages = mapOf(
            "youtube" to "com.google.android.youtube",
            "chrome" to "com.android.chrome",
            "browser" to "com.android.chrome",
            "whatsapp" to "com.whatsapp",
            "camera" to "camera",
            "maps" to "com.google.android.apps.maps",
            "google maps" to "com.google.android.apps.maps",
            "spotify" to "com.spotify.music",
            "settings" to "settings",
            "calculator" to "calculator",
            "photos" to "photos",
            "gallery" to "gallery",
            "contacts" to "contacts",
            "clock" to "clock",
            "telegram" to "org.telegram.messenger",
            "facebook" to "com.facebook.katana",
            "instagram" to "com.instagram.android",
            "twitter" to "com.twitter.android",
            "x" to "com.twitter.android",
            "gmail" to "com.google.android.gm"
        )

        // Special system intents
        if (cleanName == "camera") {
            return try {
                val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                ActionResult.Success("Camera opened", "Opening camera")
            } catch (e: Exception) {
                ActionResult.Failure("Camera open error: ${e.localizedMessage}")
            }
        }

        if (cleanName == "settings") {
            return try {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                ActionResult.Success("Settings opened", "Opening settings")
            } catch (e: Exception) {
                ActionResult.Failure("Settings open error: ${e.localizedMessage}")
            }
        }

        val targetPkg = knownPackages[cleanName]
        if (targetPkg != null) {
            val intent = pm.getLaunchIntentForPackage(targetPkg)
            if (intent != null) {
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent)
                return ActionResult.Success("Opened $appName", "Opening $appName")
            }
        }

        // Fuzzy match installed packages
        val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        for (app in installedApps) {
            val label = pm.getApplicationLabel(app).toString().lowercase()
            if (label.contains(cleanName) || cleanName.contains(label)) {
                val intent = pm.getLaunchIntentForPackage(app.packageName)
                if (intent != null) {
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    context.startActivity(intent)
                    return ActionResult.Success("Opened ${pm.getApplicationLabel(app)}", "Opening ${pm.getApplicationLabel(app)}")
                }
            }
        }

        return ActionResult.Failure("Application '$appName' not found on device.")
    }

    // --- WhatsApp Direct Message ---
    fun sendWhatsAppMessage(phoneOrName: String, messageText: String): ActionResult {
        return try {
            val cleanPhone = phoneOrName.replace("+", "").replace(" ", "").replace("-", "")
            val encodedMessage = URLEncoder.encode(messageText, "UTF-8")
            val url = if (cleanPhone.all { it.isDigit() } && cleanPhone.length >= 7) {
                "https://api.whatsapp.com/send?phone=$cleanPhone&text=$encodedMessage"
            } else {
                "https://api.whatsapp.com/send?text=$encodedMessage"
            }
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse(url)
                setPackage("com.whatsapp")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult.Success("WhatsApp message prepared for $phoneOrName", "Opening WhatsApp with your message")
        } catch (e: Exception) {
            // Fallback generic share
            try {
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, messageText)
                    setPackage("com.whatsapp")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(sendIntent)
                ActionResult.Success("WhatsApp sharing initiated", "Sharing message on WhatsApp")
            } catch (e2: Exception) {
                ActionResult.Failure("WhatsApp is not installed.")
            }
        }
    }

    // --- Phone Call ---
    fun makePhoneCall(number: String): ActionResult {
        return try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:$number")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult.Success("Dialing $number", "Dialing $number")
        } catch (e: Exception) {
            ActionResult.Failure("Dialer error: ${e.localizedMessage}")
        }
    }

    // --- Web Search ---
    fun searchWeb(query: String): ActionResult {
        return try {
            val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                putExtra(SearchManager.QUERY, query)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult.Success("Searching for: $query", "Searching web for $query")
        } catch (e: Exception) {
            // Fallback browser
            try {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${URLEncoder.encode(query, "UTF-8")}")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(browserIntent)
                ActionResult.Success("Searching for: $query", "Searching web for $query")
            } catch (e2: Exception) {
                ActionResult.Failure("Web search error: ${e2.localizedMessage}")
            }
        }
    }

    // --- Alarm / Timer ---
    fun setTimer(seconds: Int, label: String = "Jarvis Timer"): ActionResult {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                putExtra(AlarmClock.EXTRA_MESSAGE, label)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult.Success("Timer set for $seconds seconds", "Timer set for $seconds seconds")
        } catch (e: Exception) {
            ActionResult.Failure("Timer setup failed: ${e.localizedMessage}")
        }
    }

    // --- Settings Shortcuts ---
    fun openWifiSettings(): ActionResult {
        return try {
            val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult.Success("Wi-Fi settings opened", "Opening Wi-Fi settings")
        } catch (e: Exception) {
            ActionResult.Failure("Cannot open Wi-Fi settings")
        }
    }

    fun openBluetoothSettings(): ActionResult {
        return try {
            val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult.Success("Bluetooth settings opened", "Opening Bluetooth settings")
        } catch (e: Exception) {
            ActionResult.Failure("Cannot open Bluetooth settings")
        }
    }

    // --- Screen Vision & Autonomous Automation ---
    fun readScreen(): ActionResult {
        val service = BrainAccessibilityService.instance
        if (service == null) {
            return ActionResult.Failure("Accessibility Service is not enabled. Enable 'Brain AI Jarvis Automation' in Accessibility Settings.")
        }
        val screenHierarchy = service.readScreenTextHierarchy()
        return ActionResult.ScreenAnalysis(screenHierarchy)
    }

    fun tapOnScreen(targetText: String): ActionResult {
        val service = BrainAccessibilityService.instance
        if (service == null) {
            return ActionResult.Failure("Accessibility Service is not enabled. Enable 'Brain AI Jarvis Automation' in Accessibility Settings.")
        }
        val success = service.performTapOnText(targetText)
        return if (success) {
            ActionResult.Success("Tapped on '$targetText'", "Tapped $targetText")
        } else {
            ActionResult.Failure("Could not find button or text matching '$targetText' on current screen.")
        }
    }

    fun typeOnScreen(textToType: String, targetField: String = ""): ActionResult {
        val service = BrainAccessibilityService.instance
        if (service == null) {
            return ActionResult.Failure("Accessibility Service is not enabled. Enable 'Brain AI Jarvis Automation' in Accessibility Settings.")
        }
        val success = service.performTypeText(textToType, targetField)
        return if (success) {
            ActionResult.Success("Typed '$textToType'", "Typed $textToType")
        } else {
            ActionResult.Failure("No active or matching input field found on screen.")
        }
    }

    fun scrollScreen(direction: String): ActionResult {
        val service = BrainAccessibilityService.instance
        if (service == null) {
            return ActionResult.Failure("Accessibility Service is not enabled. Enable 'Brain AI Jarvis Automation' in Accessibility Settings.")
        }
        val success = if (direction.equals("up", ignoreCase = true)) {
            service.performScrollUp()
        } else {
            service.performScrollDown()
        }
        return if (success) {
            ActionResult.Success("Scrolled $direction", "Scrolled $direction")
        } else {
            ActionResult.Failure("Unable to scroll screen.")
        }
    }

    fun performSystemNavigation(action: String): ActionResult {
        val service = BrainAccessibilityService.instance
        if (service == null) {
            return ActionResult.Failure("Accessibility Service is not enabled.")
        }
        val success = when (action.lowercase()) {
            "back" -> service.goBack()
            "home" -> service.goHome()
            "recents" -> service.openRecents()
            "notifications" -> service.openNotifications()
            "quick_settings" -> service.openQuickSettings()
            "lock" -> service.lockScreen()
            "screenshot" -> service.takeScreenshot()
            else -> false
        }
        return if (success) {
            ActionResult.Success("Executed $action", "Executing $action")
        } else {
            ActionResult.Failure("Could not perform $action navigation.")
        }
    }
}
