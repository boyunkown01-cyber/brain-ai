package com.example.engine

sealed class ParsedIntent {
    data class Flashlight(val enabled: Boolean) : ParsedIntent()
    data class Volume(val delta: Int, val isMax: Boolean = false, val isMute: Boolean = false) : ParsedIntent()
    data class LaunchApp(val appName: String) : ParsedIntent()
    data class WhatsAppMessage(val target: String, val message: String) : ParsedIntent()
    data class PhoneCall(val number: String) : ParsedIntent()
    data class WebSearch(val query: String) : ParsedIntent()
    data class Timer(val seconds: Int, val label: String) : ParsedIntent()
    data class SettingsAction(val type: String) : ParsedIntent()
    data class ScreenRead(val question: String? = null) : ParsedIntent()
    data class ScreenTap(val target: String) : ParsedIntent()
    data class ScreenType(val text: String, val targetField: String = "") : ParsedIntent()
    data class ScreenScroll(val direction: String) : ParsedIntent()
    data class SystemNav(val action: String) : ParsedIntent()
    data class AddTask(val title: String) : ParsedIntent()
    data class GeneralAiQuery(val query: String, val isBengali: Boolean = false) : ParsedIntent()
}

object CommandParser {

    fun parse(rawInput: String): ParsedIntent {
        val text = rawInput.trim()
        val lower = text.lowercase()

        // 1. Screen Vision & Understanding
        if (lower.contains("read screen") || lower.contains("what is on my screen") || lower.contains("what's on my screen") ||
            lower.contains("analyze screen") || lower.contains("summarize screen") ||
            lower.contains("স্ক্রিন পড়ো") || lower.contains("স্ক্রিনে কি আছে") || lower.contains("স্ক্রিন দেখো")) {
            return ParsedIntent.ScreenRead()
        }

        // 2. Screen Tap / Click
        if (lower.startsWith("tap on ") || lower.startsWith("click on ") || lower.startsWith("press ") ||
            lower.startsWith("tap ") || lower.startsWith("click ")) {
            val target = lower.removePrefix("tap on ")
                .removePrefix("click on ")
                .removePrefix("press ")
                .removePrefix("tap ")
                .removePrefix("click ").trim()
            return ParsedIntent.ScreenTap(target)
        }
        if (lower.endsWith("ট্যাপ করো") || lower.endsWith("ক্লিক করো") || lower.endsWith("চাপো")) {
            val target = lower.removeSuffix("ট্যাপ করো")
                .removeSuffix("ক্লিক করো")
                .removeSuffix("চাপো").trim()
            return ParsedIntent.ScreenTap(target)
        }

        // 3. Screen Type / Text Input
        if (lower.startsWith("type ") || lower.startsWith("write ")) {
            val content = text.substringAfter(" ").trim()
            return if (content.contains(" in ")) {
                val toType = content.substringBefore(" in ").trim()
                val targetField = content.substringAfter(" in ").trim()
                ParsedIntent.ScreenType(toType, targetField)
            } else {
                ParsedIntent.ScreenType(content)
            }
        }
        if (lower.endsWith("লিখো") || lower.endsWith("টাইপ করো")) {
            val content = text.removeSuffix("লিখো").removeSuffix("টাইপ করো").trim()
            return ParsedIntent.ScreenType(content)
        }

        // 4. Screen Scroll
        if (lower.contains("scroll down") || lower.contains("swipe down") || lower.contains("নিচে নামাও") || lower.contains("নিচে স্ক্রোল")) {
            return ParsedIntent.ScreenScroll("down")
        }
        if (lower.contains("scroll up") || lower.contains("swipe up") || lower.contains("উপরে ওঠাও") || lower.contains("উপরে স্ক্রোল")) {
            return ParsedIntent.ScreenScroll("up")
        }

        // 5. System Navigation
        if (lower == "go back" || lower == "back" || lower == "পিছনে যাও") {
            return ParsedIntent.SystemNav("back")
        }
        if (lower == "go home" || lower == "home" || lower == "হোমে যাও") {
            return ParsedIntent.SystemNav("home")
        }
        if (lower.contains("recent app") || lower.contains("recents") || lower.contains("রিসেন্ট অ্যাপ")) {
            return ParsedIntent.SystemNav("recents")
        }
        if (lower.contains("notification") || lower.contains("নোটিফিকেশন")) {
            return ParsedIntent.SystemNav("notifications")
        }
        if (lower.contains("quick settings") || lower.contains("কুইক সেটিংস")) {
            return ParsedIntent.SystemNav("quick_settings")
        }
        if (lower.contains("lock screen") || lower == "lock" || lower.contains("লক করো")) {
            return ParsedIntent.SystemNav("lock")
        }
        if (lower.contains("take screenshot") || lower.contains("screenshot") || lower.contains("স্ক্রিনশট নাও")) {
            return ParsedIntent.SystemNav("screenshot")
        }

        // 6. Flashlight
        if (lower.contains("flashlight on") || lower.contains("torch on") || lower.contains("turn on flashlight") || lower.contains("টর্চ জ্বালাও") || lower.contains("লাইট অন")) {
            return ParsedIntent.Flashlight(true)
        }
        if (lower.contains("flashlight off") || lower.contains("torch off") || lower.contains("turn off flashlight") || lower.contains("টর্চ নিভাও") || lower.contains("লাইট অফ")) {
            return ParsedIntent.Flashlight(false)
        }

        // 7. Volume
        if (lower.contains("volume up") || lower.contains("increase volume") || lower.contains("ভলিউম বাড়াও") || lower.contains("সাউন্ড বাড়াও")) {
            return ParsedIntent.Volume(delta = 1)
        }
        if (lower.contains("volume down") || lower.contains("decrease volume") || lower.contains("ভলিউম কমাও") || lower.contains("সাউন্ড কমাও")) {
            return ParsedIntent.Volume(delta = -1)
        }
        if (lower.contains("max volume") || lower.contains("full volume") || lower.contains("সর্বোচ্চ ভলিউম")) {
            return ParsedIntent.Volume(delta = 0, isMax = true)
        }
        if (lower == "mute" || lower.contains("silence") || lower.contains("মিউট করো") || lower.contains("শব্দ বন্ধ করো")) {
            return ParsedIntent.Volume(delta = 0, isMute = true)
        }

        // 8. WhatsApp Direct Message
        if (lower.startsWith("send whatsapp") || lower.startsWith("whatsapp ") || lower.contains("হোয়াটসঅ্যাপ")) {
            val after = text.replace("send whatsapp", "", ignoreCase = true)
                .replace("whatsapp", "", ignoreCase = true)
                .replace("হোয়াটসঅ্যাপ", "")
                .trim()
            val parts = if (after.contains(" saying ", ignoreCase = true)) {
                after.split(" saying ", limit = 2)
            } else if (after.contains(" to ", ignoreCase = true)) {
                after.split(" to ", limit = 2)
            } else {
                listOf(after.substringBefore(" "), after.substringAfter(" "))
            }
            val target = parts.getOrNull(0)?.trim().orEmpty()
            val msg = parts.getOrNull(1)?.trim()?.takeIf { it.isNotEmpty() } ?: "Hello from Jarvis"
            return ParsedIntent.WhatsAppMessage(target, msg)
        }

        // 9. Phone Call
        if (lower.startsWith("call ") || lower.startsWith("dial ") || lower.startsWith("ফোন করো ")) {
            val target = text.substringAfter(" ").trim()
            return ParsedIntent.PhoneCall(target)
        }

        // 10. Web Search
        if (lower.startsWith("search ") || lower.startsWith("google ") || lower.startsWith("খুঁজো ")) {
            val query = text.substringAfter(" ").trim()
            return ParsedIntent.WebSearch(query)
        }

        // 11. Timer
        if (lower.startsWith("set timer") || lower.startsWith("timer for ") || lower.contains("টাইমার দাও")) {
            val digits = lower.filter { it.isDigit() }
            val seconds = if (digits.isNotEmpty()) {
                val num = digits.toIntOrNull() ?: 60
                if (lower.contains("minute") || lower.contains("মিনিট")) num * 60 else num
            } else 60
            return ParsedIntent.Timer(seconds, "Jarvis Timer")
        }

        // 12. App Launching
        if (lower.startsWith("open ") || lower.startsWith("launch ") || lower.endsWith("খোলো") || lower.endsWith("অন করো")) {
            val app = text.removePrefix("open ").removePrefix("Open ")
                .removePrefix("launch ").removePrefix("Launch ")
                .removeSuffix("খোলো").removeSuffix("অন করো").trim()
            return ParsedIntent.LaunchApp(app)
        }

        // 13. Settings
        if (lower.contains("wifi") || lower.contains("wi-fi") || lower.contains("ওয়াইফাই")) {
            return ParsedIntent.SettingsAction("wifi")
        }
        if (lower.contains("bluetooth") || lower.contains("ব্লুটুথ")) {
            return ParsedIntent.SettingsAction("bluetooth")
        }

        // 14. Add Task
        if (lower.startsWith("add task ") || lower.startsWith("remember to ") || lower.startsWith("মনে রেখো ")) {
            val task = text.removePrefix("add task ").removePrefix("Add task ")
                .removePrefix("remember to ").removePrefix("মনে রেখো ").trim()
            return ParsedIntent.AddTask(task)
        }

        // 15. General AI Query / Bengali Detection
        val isBengali = rawInput.any { it in '\u0980'..'\u09FF' }
        return ParsedIntent.GeneralAiQuery(text, isBengali)
    }
}
