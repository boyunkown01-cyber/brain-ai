package com.example.service

import android.content.Intent
import android.speech.RecognitionService

class BrainVoiceRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        // Recognition callback pass-through
    }

    override fun onCancel(listener: Callback?) {
        // Cancel
    }

    override fun onStopListening(listener: Callback?) {
        // Stop
    }
}
