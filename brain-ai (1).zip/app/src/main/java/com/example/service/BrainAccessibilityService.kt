package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class BrainAccessibilityService : AccessibilityService() {

    companion object {
        var instance: BrainAccessibilityService? = null
            private set

        private val _isServiceConnected = MutableStateFlow(false)
        val isServiceConnected: StateFlow<Boolean> = _isServiceConnected.asStateFlow()

        fun isAccessibilityEnabled(context: Context): Boolean {
            val prefString = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            return prefString.contains(context.packageName)
        }

        fun openAccessibilitySettings(context: Context) {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isServiceConnected.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Active event stream
    }

    override fun onInterrupt() {
        _isServiceConnected.value = false
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) {
            instance = null
            _isServiceConnected.value = false
        }
    }

    // --- Screen Reading & Vision Hierarchy ---
    fun readScreenTextHierarchy(): String {
        val rootNode = rootInActiveWindow ?: return "Screen content is not currently accessible or window is protected."
        val textList = mutableListOf<String>()
        traverseNode(rootNode, textList, 0)
        return if (textList.isEmpty()) {
            "No readable text elements found on current active screen."
        } else {
            textList.joinToString("\n")
        }
    }

    private fun traverseNode(node: AccessibilityNodeInfo?, list: MutableList<String>, depth: Int) {
        if (node == null || !node.isVisibleToUser) return

        val text = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()
        val viewId = node.viewIdResourceName?.substringAfterLast("/")

        val label = when {
            !text.isNullOrEmpty() && !desc.isNullOrEmpty() && text != desc -> "$text ($desc)"
            !text.isNullOrEmpty() -> text
            !desc.isNullOrEmpty() -> desc
            else -> null
        }

        if (label != null) {
            val type = if (node.isClickable) "[Button]" else if (node.isEditable) "[InputField]" else "[Text]"
            list.add("$type $label")
        }

        for (i in 0 until node.childCount) {
            traverseNode(node.getChild(i), list, depth + 1)
        }
    }

    // --- Tap / Click Automation ---
    fun performTapOnText(target: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val cleanTarget = target.trim().lowercase()

        // 1. Try finding node directly
        val matchingNodes = mutableListOf<AccessibilityNodeInfo>()
        findMatchingNodes(rootNode, cleanTarget, matchingNodes)

        for (node in matchingNodes) {
            var clickableNode: AccessibilityNodeInfo? = node
            while (clickableNode != null && !clickableNode.isClickable) {
                clickableNode = clickableNode.parent
            }

            if (clickableNode != null && clickableNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true
            }

            // Fallback: Click center coordinates via gesture
            val bounds = Rect()
            node.getBoundsInScreen(bounds)
            if (bounds.width() > 0 && bounds.height() > 0) {
                dispatchTapGesture(bounds.centerX().toFloat(), bounds.centerY().toFloat())
                return true
            }
        }

        return false
    }

    private fun findMatchingNodes(
        node: AccessibilityNodeInfo?,
        target: String,
        results: MutableList<AccessibilityNodeInfo>
    ) {
        if (node == null || !node.isVisibleToUser) return

        val text = node.text?.toString()?.lowercase()
        val desc = node.contentDescription?.toString()?.lowercase()

        if ((text != null && text.contains(target)) || (desc != null && desc.contains(target))) {
            results.add(node)
        }

        for (i in 0 until node.childCount) {
            findMatchingNodes(node.getChild(i), target, results)
        }
    }

    // --- Typing Automation ---
    fun performTypeText(textToType: String, targetField: String = ""): Boolean {
        val rootNode = rootInActiveWindow ?: return false

        val targetNode: AccessibilityNodeInfo? = if (targetField.isNotBlank()) {
            findEditableNodeMatching(rootNode, targetField.lowercase())
        } else {
            findFirstEditableNode(rootNode)
        }

        if (targetNode != null) {
            val arguments = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, textToType)
            }
            targetNode.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            return targetNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
        }

        return false
    }

    private fun findEditableNodeMatching(node: AccessibilityNodeInfo?, target: String): AccessibilityNodeInfo? {
        if (node == null || !node.isVisibleToUser) return null
        val text = node.text?.toString()?.lowercase()
        val hint = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) node.hintText?.toString()?.lowercase() else null
        val desc = node.contentDescription?.toString()?.lowercase()

        if (node.isEditable && ((text?.contains(target) == true) || (hint?.contains(target) == true) || (desc?.contains(target) == true))) {
            return node
        }

        for (i in 0 until node.childCount) {
            val match = findEditableNodeMatching(node.getChild(i), target)
            if (match != null) return match
        }
        return null
    }

    private fun findFirstEditableNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null || !node.isVisibleToUser) return null
        if (node.isEditable) return node

        for (i in 0 until node.childCount) {
            val found = findFirstEditableNode(node.getChild(i))
            if (found != null) return found
        }
        return null
    }

    // --- Scrolling Automation ---
    fun performScrollDown(): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val scrollable = findScrollableNode(rootNode)
        if (scrollable != null && scrollable.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) {
            return true
        }

        // Gesture fallback
        val displayMetrics = resources.displayMetrics
        val startX = displayMetrics.widthPixels / 2f
        val startY = displayMetrics.heightPixels * 0.75f
        val endY = displayMetrics.heightPixels * 0.25f
        return dispatchSwipeGesture(startX, startY, startX, endY)
    }

    fun performScrollUp(): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val scrollable = findScrollableNode(rootNode)
        if (scrollable != null && scrollable.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) {
            return true
        }

        // Gesture fallback
        val displayMetrics = resources.displayMetrics
        val startX = displayMetrics.widthPixels / 2f
        val startY = displayMetrics.heightPixels * 0.25f
        val endY = displayMetrics.heightPixels * 0.75f
        return dispatchSwipeGesture(startX, startY, startX, endY)
    }

    private fun findScrollableNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null || !node.isVisibleToUser) return null
        if (node.isScrollable) return node

        for (i in 0 until node.childCount) {
            val found = findScrollableNode(node.getChild(i))
            if (found != null) return found
        }
        return null
    }

    // --- Gestures ---
    private fun dispatchTapGesture(x: Float, y: Float): Boolean {
        val path = Path().apply {
            moveTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 50)
        val builder = GestureDescription.Builder().apply {
            addStroke(stroke)
        }
        return dispatchGesture(builder.build(), null, null)
    }

    private fun dispatchSwipeGesture(startX: Float, startY: Float, endX: Float, endY: Float): Boolean {
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 300)
        val builder = GestureDescription.Builder().apply {
            addStroke(stroke)
        }
        return dispatchGesture(builder.build(), null, null)
    }

    // --- Global Actions ---
    fun goBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun goHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun openRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun openNotifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    fun openQuickSettings(): Boolean = performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
    fun lockScreen(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        } else {
            false
        }
    }
    fun takeScreenshot(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        } else {
            false
        }
    }
}
