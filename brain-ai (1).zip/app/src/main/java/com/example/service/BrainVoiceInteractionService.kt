package com.example.service

import android.content.Intent
import android.service.voice.VoiceInteractionService

class BrainVoiceInteractionService : VoiceInteractionService() {
    override fun onReady() {
        super.onReady()
    }

    override fun onShutdown() {
        super.onShutdown()
    }
}
