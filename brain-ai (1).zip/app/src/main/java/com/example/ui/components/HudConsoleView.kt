package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanDim
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.DarkNavyBorder
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.GreenSuccess
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun HudConsoleView(
    recognizedText: String,
    responseText: String,
    isListening: Boolean,
    isSpeaking: Boolean,
    isProcessing: Boolean,
    onSendCommand: (String) -> Unit,
    onStopSpeech: () -> Unit,
    onReplaySpeech: () -> Unit,
    modifier: Modifier = Modifier
) {
    var textInput by remember { mutableStateOf("") }
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(DarkNavySurface)
            .border(1.dp, DarkNavyBorder, RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Terminal,
                    contentDescription = "Console",
                    tint = CyanGlow,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "JARVIS HUD CONSOLE",
                    style = MaterialTheme.typography.titleMedium,
                    color = CyanGlow,
                    fontSize = 13.sp
                )
            }

            // Status Badge
            val statusColor = when {
                isProcessing -> AmberWarning
                isListening -> CyanGlow
                isSpeaking -> GreenSuccess
                else -> TextMuted
            }
            val statusText = when {
                isProcessing -> "ANALYZING..."
                isListening -> "LISTENING..."
                isSpeaking -> "SPEAKING"
                else -> "STANDBY"
            }

            Text(
                text = "● $statusText",
                color = statusColor,
                style = MaterialTheme.typography.labelSmall,
                fontSize = 11.sp
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Recognized Speech Display
        if (recognizedText.isNotBlank()) {
            Text(
                text = "USER INPUT > $recognizedText",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkNavyCard)
                    .padding(8.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        // Response Output Box
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(DarkNavyCard)
                .border(0.5.dp, DarkNavyBorder, RoundedCornerShape(8.dp))
                .padding(10.dp)
                .verticalScroll(scrollState)
        ) {
            Text(
                text = responseText,
                style = MaterialTheme.typography.bodyLarge,
                color = TextPrimary,
                lineHeight = 20.sp
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Input Bar & Action Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                placeholder = { Text("Command Jarvis or ask question...", fontSize = 12.sp, color = TextMuted) },
                modifier = Modifier.weight(1f),
                textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyanGlow,
                    unfocusedBorderColor = DarkNavyBorder,
                    cursorColor = CyanGlow
                ),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.width(6.dp))

            // Send Button
            IconButton(
                onClick = {
                    if (textInput.isNotBlank()) {
                        onSendCommand(textInput)
                        textInput = ""
                    }
                },
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(CyanDim)
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Send",
                    tint = TextPrimary,
                    modifier = Modifier.size(18.dp)
                )
            }

            if (isSpeaking) {
                Spacer(modifier = Modifier.width(4.dp))
                IconButton(
                    onClick = onStopSpeech,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(AmberWarning.copy(alpha = 0.3f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Stop,
                        contentDescription = "Stop Speech",
                        tint = AmberWarning,
                        modifier = Modifier.size(18.dp)
                    )
                }
            } else if (responseText.isNotBlank()) {
                Spacer(modifier = Modifier.width(4.dp))
                IconButton(
                    onClick = onReplaySpeech,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(DarkNavyCard)
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = "Replay",
                        tint = CyanGlow,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
