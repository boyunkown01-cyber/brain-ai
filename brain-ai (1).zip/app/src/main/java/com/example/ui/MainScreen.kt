package com.example.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assistant
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.AssistantOverlayActivity
import com.example.ui.components.CommandDirectoryModal
import com.example.ui.components.EncryptedTaskManager
import com.example.ui.components.EncryptedVaultView
import com.example.ui.components.HudConsoleView
import com.example.ui.components.QuickCommandGrid
import com.example.ui.components.SystemTelemetryBar
import com.example.ui.components.VoiceOrbVisualizer
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BlueNeon
import com.example.ui.theme.CyanDim
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.DarkNavyBorder
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.GreenSuccess
import com.example.ui.theme.PurpleAccent
import com.example.ui.theme.RedAlert
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.BrainViewModel

data class NavTab(val title: String, val icon: ImageVector)

@Composable
fun MainScreen(
    viewModel: BrainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val tasks by viewModel.tasks.collectAsState()
    val vaultSecrets by viewModel.vaultSecrets.collectAsState()

    var showCommandDirectory by remember { mutableStateOf(false) }

    // Audio record permission launcher
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.startListening()
        }
    }

    LaunchedEffect(Unit) {
        viewModel.checkAccessibilityStatus()
    }

    val tabs = listOf(
        NavTab("HUD Core", Icons.Default.GraphicEq),
        NavTab("Directory", Icons.Default.MenuBook),
        NavTab("Tasks", Icons.Default.ListAlt),
        NavTab("Vault", Icons.Default.Lock)
    )

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = DarkNavyBg,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkNavyBg)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // Main Header Title
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(CyanGlow.copy(alpha = 0.2f))
                                .border(1.dp, CyanGlow, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = "Jarvis Core",
                                tint = CyanGlow,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "BRAIN AI // JARVIS",
                                style = MaterialTheme.typography.titleMedium,
                                color = CyanGlow,
                                fontSize = 15.sp,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "AUTONOMOUS AGENT v2.0",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary,
                                fontSize = 9.sp
                            )
                        }
                    }

                    // Test Overlay Button
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(DarkNavyCard)
                            .border(1.dp, CyanDim, RoundedCornerShape(8.dp))
                            .clickable {
                                val intent = Intent(context, AssistantOverlayActivity::class.java).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                                }
                                context.startActivity(intent)
                            }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("overlay_test_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Assistant,
                                contentDescription = "Assist Overlay",
                                tint = CyanGlow,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "OVERLAY",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyanGlow,
                                fontSize = 10.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Telemetry Bar
                SystemTelemetryBar(
                    isAccessibilityActive = uiState.isAccessibilityActive,
                    selectedLanguage = uiState.selectedLanguage,
                    onToggleLanguage = { viewModel.toggleLanguage() },
                    onAccessibilityClick = { viewModel.openAccessibilitySettings() }
                )

                // Accessibility Banner if Disabled
                if (!uiState.isAccessibilityActive) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(AmberWarning.copy(alpha = 0.12f))
                            .border(1.dp, AmberWarning.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .clickable { viewModel.openAccessibilitySettings() }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("accessibility_warning_banner")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = "Warning",
                                    tint = AmberWarning,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Enable Accessibility for Screen Vision & Tap/Scroll automation",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AmberWarning,
                                    fontSize = 10.sp
                                )
                            }
                            Text(
                                text = "ENABLE",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyanGlow,
                                fontSize = 10.sp,
                                modifier = Modifier
                                    .padding(start = 6.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(DarkNavySurface)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = DarkNavySurface,
                tonalElevation = 0.dp,
                modifier = Modifier
                    .border(width = 1.dp, color = DarkNavyBorder)
                    .testTag("navigation_bar")
            ) {
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = uiState.activeTab == index,
                        onClick = { viewModel.switchTab(index) },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.title,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CyanGlow,
                            selectedTextColor = CyanGlow,
                            indicatorColor = DarkNavyCard,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        ),
                        modifier = Modifier.testTag("nav_tab_$index")
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(DarkNavyBg),
            contentAlignment = Alignment.TopCenter
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 680.dp)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                when (uiState.activeTab) {
                    0 -> {
                        // Main Core HUD Tab
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState()),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Spacer(modifier = Modifier.height(10.dp))

                            // Interactive Pulsing Voice Orb Visualizer
                            VoiceOrbVisualizer(
                                isListening = uiState.isListening,
                                isSpeaking = uiState.isSpeaking,
                                isProcessing = uiState.isProcessing,
                                audioRms = uiState.audioRms,
                                onClick = {
                                    if (uiState.isListening) {
                                        viewModel.stopListening()
                                    } else {
                                        val hasPermission = ContextCompat.checkSelfPermission(
                                            context,
                                            Manifest.permission.RECORD_AUDIO
                                        ) == PackageManager.PERMISSION_GRANTED

                                        if (hasPermission) {
                                            viewModel.startListening()
                                        } else {
                                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                        }
                                    }
                                },
                                modifier = Modifier.testTag("voice_orb_visualizer")
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            // HUD Console View (Interactive Input / Response Terminal)
                            HudConsoleView(
                                recognizedText = uiState.lastRecognizedText,
                                responseText = uiState.lastResponseText,
                                isListening = uiState.isListening,
                                isSpeaking = uiState.isSpeaking,
                                isProcessing = uiState.isProcessing,
                                onSendCommand = { cmd -> viewModel.processCommand(cmd, isVoice = false) },
                                onStopSpeech = { viewModel.stopSpeaking() },
                                onReplaySpeech = {
                                    val isBn = uiState.selectedLanguage == "bn-BD"
                                    viewModel.ttsEngine.speak(uiState.lastResponseText, isBengali = isBn)
                                },
                                modifier = Modifier.testTag("hud_console_view")
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Quick Automation Command Grid
                            QuickCommandGrid(
                                onExecute = { cmd -> viewModel.processCommand(cmd, isVoice = false) },
                                onOpenGuide = { showCommandDirectory = true },
                                modifier = Modifier.testTag("quick_command_grid")
                            )

                            Spacer(modifier = Modifier.height(18.dp))
                        }
                    }

                    1 -> {
                        // Full-view Directory / Modal Embedded
                        CommandDirectoryModal(
                            onDismiss = { viewModel.switchTab(0) },
                            onExecuteSample = { sample ->
                                viewModel.processCommand(sample, isVoice = false)
                                viewModel.switchTab(0)
                            }
                        )
                    }

                    2 -> {
                        // Encrypted Task Manager
                        EncryptedTaskManager(
                            tasks = tasks,
                            onAddTask = { title, isEncrypted, passcode ->
                                viewModel.addTask(title, isEncrypted, passcode)
                            },
                            onToggleTask = { task -> viewModel.toggleTask(task) },
                            onDeleteTask = { task -> viewModel.deleteTask(task) },
                            modifier = Modifier.testTag("encrypted_task_manager")
                        )
                    }

                    3 -> {
                        // Encrypted Security Vault
                        EncryptedVaultView(
                            secrets = vaultSecrets,
                            onSaveSecret = { title, secret, passcode, cat ->
                                viewModel.saveVaultSecret(title, secret, passcode, cat)
                            },
                            onDeleteSecret = { secret -> viewModel.deleteVaultSecret(secret) },
                            modifier = Modifier.testTag("encrypted_vault_view")
                        )
                    }
                }
            }

            // Command Directory Modal popup if triggered from QuickCommandGrid
            if (showCommandDirectory) {
                CommandDirectoryModal(
                    onDismiss = { showCommandDirectory = false },
                    onExecuteSample = { sampleCmd ->
                        showCommandDirectory = false
                        viewModel.processCommand(sampleCmd, isVoice = false)
                    }
                )
            }
        }
    }
}
