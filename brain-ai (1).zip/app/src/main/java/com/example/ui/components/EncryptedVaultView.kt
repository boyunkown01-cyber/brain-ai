package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.VaultSecretEntity
import com.example.security.CryptoManager
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanDim
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.DarkNavyBorder
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.RedAlert
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun EncryptedVaultView(
    secrets: List<VaultSecretEntity>,
    onSaveSecret: (String, String, String, String) -> Unit,
    onDeleteSecret: (VaultSecretEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var title by remember { mutableStateOf("") }
    var payload by remember { mutableStateOf("") }
    var passcode by remember { mutableStateOf("") }
    var unlockPasscode by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(16.dp))
            .background(DarkNavySurface)
            .border(1.dp, DarkNavyBorder, RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        // Title
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.VpnKey,
                contentDescription = "Vault",
                tint = AmberWarning,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "JARVIS ENCRYPTED CREDENTIAL VAULT",
                style = MaterialTheme.typography.titleMedium,
                color = AmberWarning,
                fontSize = 13.sp
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // New Secret Inputs
        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            placeholder = { Text("Title / Label (e.g. WiFi Key, Bank PIN)", fontSize = 11.sp, color = TextMuted) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = AmberWarning,
                unfocusedBorderColor = DarkNavyBorder,
                cursorColor = AmberWarning
            ),
            shape = RoundedCornerShape(8.dp)
        )

        Spacer(modifier = Modifier.height(6.dp))

        OutlinedTextField(
            value = payload,
            onValueChange = { payload = it },
            placeholder = { Text("Secret / Sensitive Payload", fontSize = 11.sp, color = TextMuted) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = AmberWarning,
                unfocusedBorderColor = DarkNavyBorder,
                cursorColor = AmberWarning
            ),
            shape = RoundedCornerShape(8.dp)
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = passcode,
                onValueChange = { passcode = it },
                placeholder = { Text("AES Key / Passcode", fontSize = 11.sp, color = TextMuted) },
                modifier = Modifier.weight(1f),
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AmberWarning,
                    unfocusedBorderColor = DarkNavyBorder,
                    cursorColor = AmberWarning
                ),
                shape = RoundedCornerShape(8.dp)
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = {
                    if (title.isNotBlank() && payload.isNotBlank() && passcode.isNotBlank()) {
                        onSaveSecret(title, payload, passcode, "PASSWORD")
                        title = ""
                        payload = ""
                        passcode = ""
                    }
                },
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyanDim)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Save",
                    tint = TextPrimary
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Unlock filter
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(DarkNavyCard)
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(
                text = "MASTER UNLOCK KEY:",
                style = MaterialTheme.typography.labelSmall,
                color = CyanGlow,
                fontSize = 10.sp
            )
            Spacer(modifier = Modifier.width(6.dp))
            OutlinedTextField(
                value = unlockPasscode,
                onValueChange = { unlockPasscode = it },
                placeholder = { Text("Passcode to reveal", fontSize = 10.sp, color = TextMuted) },
                modifier = Modifier.weight(1f),
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyanGlow,
                    unfocusedBorderColor = DarkNavyBorder,
                    cursorColor = CyanGlow
                ),
                shape = RoundedCornerShape(6.dp)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(secrets) { secret ->
                val decryptedText = if (unlockPasscode.isNotBlank()) {
                    CryptoManager.decrypt(secret.encryptedPayload, unlockPasscode)
                } else {
                    "•••••••• (Locked)"
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(DarkNavyCard)
                        .border(0.5.dp, DarkNavyBorder, RoundedCornerShape(8.dp))
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = secret.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = CyanGlow,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = decryptedText,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (unlockPasscode.isNotBlank()) TextPrimary else TextMuted,
                            fontSize = 12.sp
                        )
                    }

                    IconButton(
                        onClick = { onDeleteSecret(secret) },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = RedAlert.copy(alpha = 0.8f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}
