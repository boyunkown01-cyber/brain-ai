package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BlueNeon
import com.example.ui.theme.CyanDim
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.PurpleAccent
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun VoiceOrbVisualizer(
    isListening: Boolean,
    isSpeaking: Boolean,
    isProcessing: Boolean,
    audioRms: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "OrbPulse")

    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isListening) 2000 else 6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Rotation"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Pulse"
    )

    val activeColor = when {
        isProcessing -> AmberWarning
        isListening -> CyanGlow
        isSpeaking -> PurpleAccent
        else -> BlueNeon
    }

    Box(
        modifier = modifier
            .size(160.dp)
            .clip(CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(150.dp)) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val baseRadius = (size.minDimension / 2f) * 0.7f * pulseScale
            val dynamicBoost = if (isListening) (audioRms * 2.5f).coerceAtMost(25f) else 0f
            val radius = baseRadius + dynamicBoost

            // Outer Arc Ring
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(activeColor.copy(alpha = 0.25f), Color.Transparent),
                    center = center,
                    radius = radius * 1.35f
                ),
                radius = radius * 1.35f,
                center = center
            )

            // Revolving HUD tick segments
            val segmentCount = 12
            for (i in 0 until segmentCount) {
                val angleDeg = (i * (360f / segmentCount)) + rotation
                val angleRad = Math.toRadians(angleDeg.toDouble())
                val startDist = radius * 1.05f
                val endDist = radius * 1.18f + (if (i % 2 == 0) dynamicBoost else 0f)

                val start = Offset(
                    (center.x + startDist * cos(angleRad)).toFloat(),
                    (center.y + startDist * sin(angleRad)).toFloat()
                )
                val end = Offset(
                    (center.x + endDist * cos(angleRad)).toFloat(),
                    (center.y + endDist * sin(angleRad)).toFloat()
                )

                drawLine(
                    color = activeColor.copy(alpha = 0.7f),
                    start = start,
                    end = end,
                    strokeWidth = 3f,
                    cap = StrokeCap.Round
                )
            }

            // Inner Core Arc Reactor
            drawCircle(
                color = CyanDim.copy(alpha = 0.3f),
                radius = radius * 0.85f,
                center = center,
                style = Stroke(width = 4f)
            )

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White, activeColor, CyanDim),
                    center = center,
                    radius = radius * 0.65f
                ),
                radius = radius * 0.65f,
                center = center
            )
        }
    }
}
