package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.TaskEntity
import com.example.security.CryptoManager
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanDim
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.DarkNavyBorder
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.GreenSuccess
import com.example.ui.theme.RedAlert
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun EncryptedTaskManager(
    tasks: List<TaskEntity>,
    onAddTask: (String, Boolean, String) -> Unit,
    onToggleTask: (TaskEntity) -> Unit,
    onDeleteTask: (TaskEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var newTaskTitle by remember { mutableStateOf("") }
    var isEncrypted by remember { mutableStateOf(false) }
    var passcode by remember { mutableStateOf("") }
    var viewPasscode by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(16.dp))
            .background(DarkNavySurface)
            .border(1.dp, DarkNavyBorder, RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        // Title
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "Encrypted Tasks",
                tint = CyanGlow,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "JARVIS OFFLINE TASK VAULT",
                style = MaterialTheme.typography.titleMedium,
                color = CyanGlow,
                fontSize = 14.sp
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Input Row
        OutlinedTextField(
            value = newTaskTitle,
            onValueChange = { newTaskTitle = it },
            placeholder = { Text("Enter task or objective...", fontSize = 12.sp, color = TextMuted) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = CyanGlow,
                unfocusedBorderColor = DarkNavyBorder,
                cursorColor = CyanGlow
            ),
            shape = RoundedCornerShape(10.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = isEncrypted,
                    onCheckedChange = { isEncrypted = it },
                    colors = CheckboxDefaults.colors(
                        checkedColor = CyanGlow,
                        uncheckedColor = TextMuted,
                        checkmarkColor = DarkNavySurface
                    )
                )
                Text(
                    text = "AES Encrypt",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isEncrypted) CyanGlow else TextMuted
                )
            }

            if (isEncrypted) {
                OutlinedTextField(
                    value = passcode,
                    onValueChange = { passcode = it },
                    placeholder = { Text("Passcode", fontSize = 10.sp, color = TextMuted) },
                    modifier = Modifier.width(110.dp),
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AmberWarning,
                        unfocusedBorderColor = DarkNavyBorder,
                        cursorColor = AmberWarning
                    ),
                    shape = RoundedCornerShape(8.dp)
                )
            }

            IconButton(
                onClick = {
                    if (newTaskTitle.isNotBlank()) {
                        onAddTask(newTaskTitle, isEncrypted, passcode)
                        newTaskTitle = ""
                        passcode = ""
                    }
                },
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyanDim)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add",
                    tint = TextPrimary
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Global Decrypt Passcode Filter Bar
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(DarkNavyCard)
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(
                text = "DECRYPT KEY:",
                style = MaterialTheme.typography.labelSmall,
                color = AmberWarning,
                fontSize = 10.sp
            )
            Spacer(modifier = Modifier.width(6.dp))
            OutlinedTextField(
                value = viewPasscode,
                onValueChange = { viewPasscode = it },
                placeholder = { Text("Enter pass to decrypt", fontSize = 10.sp, color = TextMuted) },
                modifier = Modifier.weight(1f),
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AmberWarning,
                    unfocusedBorderColor = DarkNavyBorder,
                    cursorColor = AmberWarning
                ),
                shape = RoundedCornerShape(6.dp)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // List of Tasks
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(tasks) { task ->
                val displayTitle = if (task.isEncrypted) {
                    if (viewPasscode.isNotBlank()) {
                        CryptoManager.decrypt(task.title, viewPasscode)
                    } else {
                        "🔒 [Encrypted Payload - Enter Key]"
                    }
                } else {
                    task.title
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(DarkNavyCard)
                        .border(0.5.dp, DarkNavyBorder, RoundedCornerShape(10.dp))
                        .clickable { onToggleTask(task) }
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = if (task.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                            contentDescription = "Status",
                            tint = if (task.isCompleted) GreenSuccess else TextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = displayTitle,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (task.isCompleted) TextMuted else TextPrimary,
                            fontSize = 13.sp
                        )
                    }

                    IconButton(
                        onClick = { onDeleteTask(task) },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = RedAlert.copy(alpha = 0.8f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}
