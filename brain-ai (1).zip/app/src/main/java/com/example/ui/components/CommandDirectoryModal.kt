package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assistant
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BlueNeon
import com.example.ui.theme.CyanDim
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.DarkNavyBorder
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.GreenSuccess
import com.example.ui.theme.PurpleAccent
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

data class CommandItem(
    val title: String,
    val purpose: String,
    val voiceExamples: List<String>,
    val category: String,
    val icon: ImageVector
)

val JarvisCommandDirectory = listOf(
    // 1. Screen Vision & Understanding
    CommandItem(
        title = "Screen Vision & Read",
        purpose = "Inspects the active app screen, extracts text and UI elements, and provides an AI summary or answers questions about the screen.",
        voiceExamples = listOf("Read screen", "What's on my screen?", "স্ক্রিনে কি আছে পড়ো", "Analyze screen"),
        category = "Screen Automation",
        icon = Icons.Default.Visibility
    ),
    // 2. Screen Tap / Click Automation
    CommandItem(
        title = "Autonomous Tap & Click",
        purpose = "Finds buttons, icons, or text matching your command on the active screen and performs an automatic tap/click gesture.",
        voiceExamples = listOf("Tap on Settings", "Click Search", "Press Submit", "Settings এ ট্যাপ করো"),
        category = "Screen Automation",
        icon = Icons.Default.TouchApp
    ),
    // 3. Screen Type / Text Automation
    CommandItem(
        title = "Autonomous Typing & Input",
        purpose = "Locates input text boxes or search bars on the current screen and types the requested text automatically.",
        voiceExamples = listOf("Type Hello in Search", "Write Good Morning in Message", "Hello টাইপ করো"),
        category = "Screen Automation",
        icon = Icons.Default.Chat
    ),
    // 4. Screen Scroll Automation
    CommandItem(
        title = "Autonomous Scroll",
        purpose = "Performs vertical scrolling gestures up or down on feeds, documents, or social media pages.",
        voiceExamples = listOf("Scroll down", "Scroll up", "Swipe down", "নিচে নামাও", "উপরে ওঠাও"),
        category = "Screen Automation",
        icon = Icons.Default.PlayArrow
    ),
    // 5. System Navigation
    CommandItem(
        title = "System Gestures & Navigation",
        purpose = "Executes global Android navigation actions like Back, Home, Recents, Notifications, Quick Settings, Lock Screen, or Screenshot.",
        voiceExamples = listOf("Go back", "Go home", "Recent apps", "Open notifications", "Lock screen", "Take screenshot", "স্ক্রিনশট নাও"),
        category = "Navigation & Control",
        icon = Icons.Default.Navigation
    ),
    // 6. Home Button Assistant Overlay
    CommandItem(
        title = "Home Long-Press Overlay",
        purpose = "Summons the floating Jarvis bottom assistant overlay over any app when long-pressing the Home button (just like Google Assistant/Gemini).",
        voiceExamples = listOf("Long-press Home button to trigger floating Jarvis popup", "Summon assistant anytime"),
        category = "Navigation & Control",
        icon = Icons.Default.Assistant
    ),
    // 7. Flashlight Control
    CommandItem(
        title = "Flashlight & Torch",
        purpose = "Turns your phone's physical rear LED camera flashlight on or off instantly.",
        voiceExamples = listOf("Turn on flashlight", "Torch off", "টর্চ জ্বালাও", "লাইট নিভাও"),
        category = "Device Controls",
        icon = Icons.Default.FlashlightOn
    ),
    // 8. Volume & Sound Control
    CommandItem(
        title = "Volume & Audio Output",
        purpose = "Increases, decreases, mutes, or sets media sound volume to maximum.",
        voiceExamples = listOf("Volume up", "Volume down", "Mute sound", "Max volume", "ভলিউম বাড়াও"),
        category = "Device Controls",
        icon = Icons.Default.VolumeUp
    ),
    // 9. WhatsApp Direct Messaging
    CommandItem(
        title = "WhatsApp Direct Message",
        purpose = "Opens WhatsApp and pre-fills a direct message for any contact name or international phone number.",
        voiceExamples = listOf("Send WhatsApp to +1234567890 saying Hello", "WhatsApp John I am on my way"),
        category = "Messaging & Calls",
        icon = Icons.Default.Chat
    ),
    // 10. Phone Calls & Dialing
    CommandItem(
        title = "Phone Call & Dialing",
        purpose = "Opens the device dialer ready to call the specified number.",
        voiceExamples = listOf("Call 911", "Dial 1234567890", "ফোন করো 12345"),
        category = "Messaging & Calls",
        icon = Icons.Default.Phone
    ),
    // 11. Web & Knowledge Search
    CommandItem(
        title = "Web & AI Search",
        purpose = "Searches Google or queries Gemini AI knowledge engine for any topic, calculation, translation, or definition.",
        voiceExamples = listOf("Search latest AI news", "Calculate 15% of 850", "What is quantum computing?", "খুঁজো আজকের আবহাওয়া"),
        category = "AI & Knowledge",
        icon = Icons.Default.Search
    ),
    // 12. Bilingual Voice (English & Bengali)
    CommandItem(
        title = "Bilingual Voice Engine",
        purpose = "Seamlessly speaks and understands both English and Bengali (বাংলা) with native text-to-speech cadence.",
        voiceExamples = listOf("Tap language badge to toggle EN / বাংলা", "তুমি কেমন আছো?", "আজকের আবহাওয়া কেমন?"),
        category = "AI & Knowledge",
        icon = Icons.Default.Language
    )
)

@Composable
fun CommandDirectoryModal(
    onDismiss: () -> Unit,
    onExecuteSample: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }

    val categories = listOf("All", "Screen Automation", "Navigation & Control", "Device Controls", "Messaging & Calls", "AI & Knowledge")

    val filteredItems = JarvisCommandDirectory.filter { item ->
        val matchesCategory = selectedCategory == "All" || item.category == selectedCategory
        val matchesSearch = searchQuery.isBlank() ||
                item.title.contains(searchQuery, ignoreCase = true) ||
                item.purpose.contains(searchQuery, ignoreCase = true) ||
                item.voiceExamples.any { it.contains(searchQuery, ignoreCase = true) }
        matchesCategory && matchesSearch
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(DarkNavyBg)
                .padding(16.dp),
            color = DarkNavyBg
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "JARVIS COMMAND DIRECTORY",
                            style = MaterialTheme.typography.titleLarge,
                            color = CyanGlow,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Purpose & Voice Examples Guide",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(DarkNavyCard)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = CyanGlow
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search command purpose or phrase...", fontSize = 12.sp, color = TextMuted) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = CyanGlow) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanGlow,
                        unfocusedBorderColor = DarkNavyBorder,
                        cursorColor = CyanGlow
                    ),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Category Chips Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.take(3).forEach { cat ->
                        CategoryChip(
                            name = cat,
                            isSelected = selectedCategory == cat,
                            onClick = { selectedCategory = cat }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.drop(3).forEach { cat ->
                        CategoryChip(
                            name = cat,
                            isSelected = selectedCategory == cat,
                            onClick = { selectedCategory = cat }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // List of Commands
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    items(filteredItems) { item ->
                        CommandCard(
                            item = item,
                            onExecuteSample = { sample ->
                                onDismiss()
                                onExecuteSample(sample)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CategoryChip(
    name: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) CyanDim else DarkNavySurface)
            .border(1.dp, if (isSelected) CyanGlow else DarkNavyBorder, RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = name,
            style = MaterialTheme.typography.labelSmall,
            color = if (isSelected) TextPrimary else TextSecondary,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun CommandCard(
    item: CommandItem,
    onExecuteSample: (String) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, DarkNavyBorder, RoundedCornerShape(12.dp)),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DarkNavySurface)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(DarkNavyCard)
                            .border(0.5.dp, CyanDim, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.title,
                            tint = CyanGlow,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = item.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = CyanGlow,
                            fontSize = 14.sp
                        )
                        Text(
                            text = item.category,
                            style = MaterialTheme.typography.labelSmall,
                            color = AmberWarning,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Purpose Description
            Text(
                text = "Purpose: ${item.purpose}",
                style = MaterialTheme.typography.bodyMedium,
                color = TextPrimary,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Sample voice commands
            Text(
                text = "Voice Examples (Tap to try):",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                fontSize = 10.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                item.voiceExamples.forEach { example ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(DarkNavyCard)
                            .clickable { onExecuteSample(example) }
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "🗣 \"$example\"",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Run",
                            tint = CyanGlow,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}
