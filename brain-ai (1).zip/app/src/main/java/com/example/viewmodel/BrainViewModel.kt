package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.BrainDatabase
import com.example.data.local.entities.CommandLogEntity
import com.example.data.local.entities.PluginEntity
import com.example.data.local.entities.TaskEntity
import com.example.data.local.entities.VaultSecretEntity
import com.example.data.repository.BrainRepository
import com.example.engine.ActionResult
import com.example.engine.CommandParser
import com.example.engine.DeviceActionExecutor
import com.example.engine.ParsedIntent
import com.example.security.CryptoManager
import com.example.service.BrainAccessibilityService
import com.example.speech.TtsEngine
import com.example.speech.VoiceEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class JarvisUiState(
    val lastRecognizedText: String = "",
    val lastResponseText: String = "Jarvis Core v2.0 Online. Standing by for voice or automation command.",
    val isListening: Boolean = false,
    val isSpeaking: Boolean = false,
    val isProcessing: Boolean = false,
    val audioRms: Float = 0f,
    val selectedLanguage: String = "en-US", // or bn-BD
    val isAccessibilityActive: Boolean = false,
    val activeTab: Int = 0 // 0: HUD/Voice, 1: Commands Directory, 2: Tasks, 3: Vault, 4: Plugins, 5: Apps
)

class BrainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: BrainRepository
    private val actionExecutor: DeviceActionExecutor
    val voiceEngine: VoiceEngine
    val ttsEngine: TtsEngine

    private val _uiState = MutableStateFlow(JarvisUiState())
    val uiState: StateFlow<JarvisUiState> = _uiState.asStateFlow()

    val commandLogs: StateFlow<List<CommandLogEntity>>
    val tasks: StateFlow<List<TaskEntity>>
    val vaultSecrets: StateFlow<List<VaultSecretEntity>>
    val plugins: StateFlow<List<PluginEntity>>

    init {
        val db = BrainDatabase.getDatabase(application)
        repository = BrainRepository(db.brainDao())
        actionExecutor = DeviceActionExecutor(application)
        voiceEngine = VoiceEngine(application)
        ttsEngine = TtsEngine(application)

        commandLogs = repository.recentLogs.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        tasks = repository.allTasks.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        vaultSecrets = repository.allVaultSecrets.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        plugins = repository.allPlugins.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        // Listen for speech results
        voiceEngine.onResultCallback = { spokenText ->
            processCommand(spokenText, isVoice = true)
        }

        viewModelScope.launch {
            voiceEngine.isListening.collect { listening ->
                _uiState.value = _uiState.value.copy(isListening = listening)
            }
        }

        viewModelScope.launch {
            voiceEngine.rmsDb.collect { rms ->
                _uiState.value = _uiState.value.copy(audioRms = rms)
            }
        }

        viewModelScope.launch {
            ttsEngine.isSpeaking.collect { speaking ->
                _uiState.value = _uiState.value.copy(isSpeaking = speaking)
            }
        }

        // Periodic check for accessibility service connection
        checkAccessibilityStatus()
    }

    fun checkAccessibilityStatus() {
        val isConn = BrainAccessibilityService.isAccessibilityEnabled(getApplication())
        _uiState.value = _uiState.value.copy(isAccessibilityActive = isConn)
    }

    fun openAccessibilitySettings() {
        BrainAccessibilityService.openAccessibilitySettings(getApplication())
    }

    fun switchTab(tabIndex: Int) {
        _uiState.value = _uiState.value.copy(activeTab = tabIndex)
    }

    fun toggleLanguage() {
        val current = _uiState.value.selectedLanguage
        val next = if (current == "en-US") "bn-BD" else "en-US"
        _uiState.value = _uiState.value.copy(selectedLanguage = next)
        val msg = if (next == "bn-BD") "বাংলা ভাষা সক্রিয় করা হয়েছে।" else "Switched to English."
        ttsEngine.speak(msg, isBengali = next == "bn-BD")
    }

    fun startListening() {
        _uiState.value = _uiState.value.copy(isListening = true)
        voiceEngine.startListening(_uiState.value.selectedLanguage)
    }

    fun stopListening() {
        voiceEngine.stopListening()
        _uiState.value = _uiState.value.copy(isListening = false)
    }

    fun stopSpeaking() {
        ttsEngine.stop()
        _uiState.value = _uiState.value.copy(isSpeaking = false)
    }

    fun processCommand(commandText: String, isVoice: Boolean = false) {
        if (commandText.isBlank()) return

        _uiState.value = _uiState.value.copy(
            lastRecognizedText = commandText,
            isProcessing = true
        )

        viewModelScope.launch {
            val intent = CommandParser.parse(commandText)
            var response = ""
            var speech = ""
            var isBengali = _uiState.value.selectedLanguage == "bn-BD" || commandText.any { it in '\u0980'..'\u09FF' }

            when (intent) {
                is ParsedIntent.ScreenRead -> {
                    val res = actionExecutor.readScreen()
                    if (res is ActionResult.ScreenAnalysis) {
                        val prompt = "Here is the active screen UI hierarchy of the user's phone:\n${res.content}\n\nPlease summarize key information, visible buttons, or messages for the user concisely."
                        val aiSummary = repository.queryGemini(prompt)
                        response = "Screen Analysis:\n$aiSummary"
                        speech = aiSummary
                    } else if (res is ActionResult.Failure) {
                        response = res.message
                        speech = res.message
                    }
                }

                is ParsedIntent.ScreenTap -> {
                    val res = actionExecutor.tapOnScreen(intent.target)
                    response = when (res) {
                        is ActionResult.Success -> res.message
                        is ActionResult.Failure -> res.message
                        else -> "Tap action dispatched."
                    }
                    speech = response
                }

                is ParsedIntent.ScreenType -> {
                    val res = actionExecutor.typeOnScreen(intent.text, intent.targetField)
                    response = when (res) {
                        is ActionResult.Success -> res.message
                        is ActionResult.Failure -> res.message
                        else -> "Type action dispatched."
                    }
                    speech = response
                }

                is ParsedIntent.ScreenScroll -> {
                    val res = actionExecutor.scrollScreen(intent.direction)
                    response = when (res) {
                        is ActionResult.Success -> res.message
                        is ActionResult.Failure -> res.message
                        else -> "Scroll action dispatched."
                    }
                    speech = response
                }

                is ParsedIntent.SystemNav -> {
                    val res = actionExecutor.performSystemNavigation(intent.action)
                    response = when (res) {
                        is ActionResult.Success -> res.message
                        is ActionResult.Failure -> res.message
                        else -> "Navigation performed."
                    }
                    speech = response
                }

                is ParsedIntent.Flashlight -> {
                    val res = actionExecutor.setFlashlight(intent.enabled)
                    response = if (res is ActionResult.Success) res.message else (res as ActionResult.Failure).message
                    speech = response
                }

                is ParsedIntent.Volume -> {
                    val res = when {
                        intent.isMax -> actionExecutor.setVolumeMax()
                        intent.isMute -> actionExecutor.setVolumeMute()
                        else -> actionExecutor.changeVolume(intent.delta)
                    }
                    response = if (res is ActionResult.Success) res.message else (res as ActionResult.Failure).message
                    speech = response
                }

                is ParsedIntent.LaunchApp -> {
                    val res = actionExecutor.launchAppByName(intent.appName)
                    response = if (res is ActionResult.Success) res.message else (res as ActionResult.Failure).message
                    speech = (res as? ActionResult.Success)?.speechResponse ?: response
                }

                is ParsedIntent.WhatsAppMessage -> {
                    val res = actionExecutor.sendWhatsAppMessage(intent.target, intent.message)
                    response = if (res is ActionResult.Success) res.message else (res as ActionResult.Failure).message
                    speech = (res as? ActionResult.Success)?.speechResponse ?: response
                }

                is ParsedIntent.PhoneCall -> {
                    val res = actionExecutor.makePhoneCall(intent.number)
                    response = if (res is ActionResult.Success) res.message else (res as ActionResult.Failure).message
                    speech = (res as? ActionResult.Success)?.speechResponse ?: response
                }

                is ParsedIntent.WebSearch -> {
                    val res = actionExecutor.searchWeb(intent.query)
                    response = if (res is ActionResult.Success) res.message else (res as ActionResult.Failure).message
                    speech = (res as? ActionResult.Success)?.speechResponse ?: response
                }

                is ParsedIntent.Timer -> {
                    val res = actionExecutor.setTimer(intent.seconds, intent.label)
                    response = if (res is ActionResult.Success) res.message else (res as ActionResult.Failure).message
                    speech = (res as? ActionResult.Success)?.speechResponse ?: response
                }

                is ParsedIntent.SettingsAction -> {
                    val res = if (intent.type == "wifi") actionExecutor.openWifiSettings() else actionExecutor.openBluetoothSettings()
                    response = if (res is ActionResult.Success) res.message else (res as ActionResult.Failure).message
                    speech = (res as? ActionResult.Success)?.speechResponse ?: response
                }

                is ParsedIntent.AddTask -> {
                    val taskId = repository.insertTask(TaskEntity(title = intent.title))
                    response = "Task added: \"${intent.title}\" (ID: $taskId)"
                    speech = "Task added."
                }

                is ParsedIntent.GeneralAiQuery -> {
                    val sysPrompt = if (intent.isBengali) {
                        "You are Jarvis, an ultra-smart AI assistant. Answer in clear, polite Bengali."
                    } else {
                        "You are Jarvis (Brain AI), an ultra-smart AI assistant on Android. Answer concisely and politely."
                    }
                    val aiResult = repository.queryGemini(intent.query, sysPrompt)
                    response = aiResult
                    speech = aiResult
                    isBengali = intent.isBengali
                }
            }

            // Log command
            repository.logCommand(
                rawCommand = commandText,
                actionType = intent::class.java.simpleName,
                responseSummary = response,
                isVoice = isVoice
            )

            _uiState.value = _uiState.value.copy(
                lastResponseText = response,
                isProcessing = false
            )

            // Speak response
            ttsEngine.speak(speech, isBengali = isBengali)
        }
    }

    // --- Task Actions ---
    fun addTask(title: String, isEncrypted: Boolean = false, passcode: String = "") {
        viewModelScope.launch {
            val finalTitle = if (isEncrypted && passcode.isNotBlank()) {
                CryptoManager.encrypt(title, passcode)
            } else title
            repository.insertTask(TaskEntity(title = finalTitle, isEncrypted = isEncrypted))
        }
    }

    fun toggleTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.updateTask(task.copy(isCompleted = !task.isCompleted))
        }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.deleteTask(task)
        }
    }

    // --- Vault Actions ---
    fun saveVaultSecret(title: String, secret: String, passcode: String, category: String = "NOTE") {
        viewModelScope.launch {
            val encrypted = CryptoManager.encrypt(secret, passcode)
            repository.insertSecret(VaultSecretEntity(title = title, encryptedPayload = encrypted, category = category))
        }
    }

    fun deleteVaultSecret(secret: VaultSecretEntity) {
        viewModelScope.launch {
            repository.deleteSecret(secret)
        }
    }

    // --- Plugin Actions ---
    fun addPlugin(name: String, desc: String, trigger: String, action: String) {
        viewModelScope.launch {
            val id = "plugin_${System.currentTimeMillis()}"
            repository.insertPlugin(PluginEntity(id, name, desc, trigger, action, isEnabled = true))
        }
    }

    fun togglePlugin(plugin: PluginEntity) {
        viewModelScope.launch {
            repository.updatePlugin(plugin.copy(isEnabled = !plugin.isEnabled))
        }
    }

    fun deletePlugin(plugin: PluginEntity) {
        viewModelScope.launch {
            repository.deletePlugin(plugin)
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceEngine.stopListening()
        ttsEngine.shutdown()
    }
}
